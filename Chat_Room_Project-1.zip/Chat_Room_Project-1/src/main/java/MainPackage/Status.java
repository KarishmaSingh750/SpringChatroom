package MainPackage;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}