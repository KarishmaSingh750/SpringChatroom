package MainPackage;

import org.springframework.beans.factory.annotation.Autowired;

public class MessageService {
	
	@Autowired
	private MessageRepo messagerepo;
	
	public Message saveDetails(Message message) {
		return messagerepo.save(message) ;
	}

}
