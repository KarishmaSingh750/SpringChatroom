package MainPackage;

public class UserSecurityConfig {

}
